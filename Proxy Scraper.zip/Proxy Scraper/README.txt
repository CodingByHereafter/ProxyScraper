Credits:
	Made by Hereafter#6615
Setup:
	pip install click
	pip install requests
Usage:
	py main.py --type HTTPS/SOCKS4/SOCKS5
Example:
	py main.py --type SOCKS5