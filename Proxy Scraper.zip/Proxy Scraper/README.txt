Credits:
	Made by Hereafter#6615
Setup:
	pip install click
Usage:
	py main.py --type HTTPS/SOCKS4/SOCKS5
Example:
	py main.py --type SOCKS5