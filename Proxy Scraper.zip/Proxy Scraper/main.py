#MADE BY Hereafter#6615

import requests, time, click

@click.command()
@click.option("--type", default="HTTPS", help='HTTPS/SOCKS4/SOCKS5')
def scraper(type):
    if type == 'HTTPS': name = 'https'
    elif type == 'SOCKS4': name = 'socks4'
    elif type == 'SOCKS5': name = 'socks5'
    else: print('Invalid Proxy Type. (py main.py --help)'); return
    with open(f'Links/{name}.txt', 'r') as f:
        with open('proxies.txt', 'r+') as g:
            g.truncate()
        start = time.time()
        lines = f.read().splitlines()
        amount = 0
        for x in lines:
            response = requests.get(x, headers={'user-agent': "Mozilla/5.0 (iPhone; CPU iPhone OS 5_1 like Mac OS X) AppleWebKit/534.46 (KHTML, like Gecko) Version/5.1 Mobile/9B179 Safari/7534.48.3"}).text
            content = response.split()
            for i in content:
                if ':' and '.' in i:
                    if '/' not in i:
                        if i[:1].isnumeric():
                            if i.partition(":")[2].isnumeric():
                                amount += 1
                                print(f'Proxies scraped: {amount}', end='\r')
                                f = open('proxies.txt', 'a')
                                f.write(f'{i}\n')
        end = time.time()
        print(f'\nFinished in {str((end - start))[:4]} seconds.')

if __name__ == '__main__':
    scraper()